import files.colors
import files.window
import files.intro_obj
import files.animation_images
