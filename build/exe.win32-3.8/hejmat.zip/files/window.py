class Consts_window:
    def __init__(self):
        self.WIDTH = 1024
        self.HEIGHT = 768
        self.TITLE = 'Hejmat!'
